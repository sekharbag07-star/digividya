import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../auth/screens/login_screen.dart';
import '../../payment/screens/payment_screen.dart';

import '../../notices/models/notice_model.dart';
import '../../notices/services/notice_service.dart';

import '../widgets/student_header.dart';
import '../widgets/student_notice_card.dart';
import '../widgets/student_live_class_card.dart';
import '../widgets/student_stats.dart';
import '../widgets/student_quick_actions.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({super.key});

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkSubscription();
    });
  }

  Future<void> checkSubscription() async {
    try {
      final user = FirebaseAuth.instance.currentUser;

      if (user == null) return;

      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      if (!doc.exists) return;

      final data = doc.data()!;

      bool subscriptionActive = data['subscriptionActive'] ?? false;

      bool trialActive = data['trialActive'] ?? false;

      Timestamp? trialEndTimestamp = data['trialEndDate'];

      // Auto Trial Expiry
      if (trialEndTimestamp != null) {
        final trialEnd = trialEndTimestamp.toDate();

        if (DateTime.now().isAfter(trialEnd)) {
          trialActive = false;

          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .update({'trialActive': false, 'paymentStatus': 'expired'});
        }
      }

      // Payment Screen Redirect
      if (!subscriptionActive && !trialActive) {
        if (!mounted) return;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const PaymentScreen()),
        );
      }
    } catch (e) {
      debugPrint('Subscription Check Error: $e');
    }
  }

  Future<void> logout() async {
    try {
      await FirebaseAuth.instance.signOut();

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Logout Failed: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Student Dashboard"),
        actions: [
          IconButton(onPressed: logout, icon: const Icon(Icons.logout)),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const StudentHeader(),

            const SizedBox(height: 20),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Notice Board",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 12),

            StreamBuilder<List<NoticeModel>>(
              stream: NoticeService().getNotices(role: 'student'),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const StudentNoticeCard(
                    title: "No Notices",
                    description: "No notices available right now.",
                  );
                }

                final notices = snapshot.data!;

                return Column(
                  children: notices.map((notice) {
                    return StudentNoticeCard(
                      title: notice.title,
                      description: notice.description,
                    );
                  }).toList(),
                );
              },
            ),

            const SizedBox(height: 25),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Live Classes",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 12),

            StudentLiveClassCard(
              title: "Mathematics Revision",
              teacher: "Rahul Sir",
              time: "7:00 PM",
              onJoin: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text("Live Class Integration Coming Soon"),
                  ),
                );
              },
            ),

            const SizedBox(height: 25),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "My Status",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 12),

            const StudentStats(),

            const SizedBox(height: 25),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Quick Actions",
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 12),

            const StudentQuickActions(),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
